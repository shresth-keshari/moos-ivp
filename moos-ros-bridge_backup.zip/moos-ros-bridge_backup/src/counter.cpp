#include "ros/ros.h" // ROS header for creating nodes, publishers, and subscribers
#include "std_msgs/Float64.h" // Header for Float64 message type
#include "std_msgs/Int32.h"   // Header for Int32 message type (though not used in this code)
#include "nav_msgs/Odometry.h" // Header for Odometry message type
#include "uuv_sensor_ros_plugins_msgs/DVL.h" // Header for DVL message type (custom message for underwater vehicle velocities)
#include "tf/tf.h" // Header for transforming quaternion orientations into roll, pitch, and yaw

// Global variables to store position, velocity, depth, and orientation data
std_msgs::Float64 msgx;   // X position
std_msgs::Float64 msgy;   // Y position
std_msgs::Float64 msgz;   // Z position (depth)
std_msgs::Float64 msgd;   // Negative Z position (depth)
std_msgs::Float64 velx;   // Velocity in the X direction
std_msgs::Float64 ya;     // Yaw angle
std_msgs::Float64 head;   // Heading (yaw in degrees)
std_msgs::Float64 p;      // Pitch angle

// Variables for orientation (roll, pitch, yaw)
double roll, pitch, yaw;

double pi = 3.14159; // Approximation of pi, used for radian-to-degree conversion

// Callback function to process incoming Odometry messages
void odomCallback(const nav_msgs::Odometry::ConstPtr& msg)
{
    // Extract and store position data from the Odometry message
    msgx.data = msg->pose.pose.position.y;  // Assign Y position to msgx (may be intentional)
    msgx.data = -msgx.data;                 // Negate Y position (likely to match a coordinate system)
    msgy.data = msg->pose.pose.position.x;  // Assign X position to msgy (may be intentional)
    msgy.data = -msgy.data;                 // Negate X position (coordinate system correction)
    msgz.data = msg->pose.pose.position.z;  // Assign Z position to msgz (depth)
    msgd.data = -msgz.data;                 // Assign negative Z position to msgd (depth for some systems)

    //velx.data = msg->twist.twist.linear.x;

    // Extract quaternion orientation from Odometry message
    double o_x = msg->pose.pose.orientation.x;
    double o_y = msg->pose.pose.orientation.y;
    double o_z = msg->pose.pose.orientation.z;
    double o_w = msg->pose.pose.orientation.w;

    // Convert quaternion to roll, pitch, and yaw using tf library
    tf::Quaternion quat(o_x, o_y, o_z, o_w);
    tf::Matrix3x3(quat).getRPY(roll, pitch, yaw);

    // Convert yaw (in radians) to degrees for the heading
    double heading = yaw * 180 / pi;

    // Store the orientation data
    head.data = heading + 180;   // Store heading (yaw in degrees)
    ya.data = yaw - 1.57 - 1.57;         // Store yaw (in radians)
    p.data = pitch;        // Store pitch angle

    // Optional logging 
    // ROS_INFO("Received /eca_a9/pose_gt: x = %f", msgx.data);
    // ROS_INFO("Received /eca_a9/pose_gt: y = %f", msgy.data);
    // ROS_INFO("Received /eca_a9/pose_gt: z = %f", msgz.data);
}

// Callback function to process incoming DVL (Doppler Velocity Log) messages
void dvlCallback(const uuv_sensor_ros_plugins_msgs::DVL::ConstPtr& msg)
{
    // Extract the velocity in the X direction from the DVL message
    velx.data = msg->velocity.z;

    // Make the velocity positive if it's negative (abs value)
    if (velx.data < 0)
    {
        velx.data = -velx.data;
    }

    // Optional logging 
    // ROS_INFO("Received /eca_a9/dvl: x = %f", velx.data);
}

// Main function
int main(int argc, char **argv)
{
    // Initialize the ROS node with the name "posePub"
    ros::init(argc, argv, "posePub");
    ros::NodeHandle n; // Create a node handle to interface with ROS

    // Create subscribers to receive data from specific topics
    //ros::Subscriber sub = n.subscribe("/eca_a9/pose_gt", 1000, odomCallback); // Subscribe to odometry data
    ros::Subscriber sub = n.subscribe("/lauv/pose_gt", 1000, odomCallback); // Subscribe to odometry data
    ros::Subscriber subdvl = n.subscribe("/lauv/dvl", 1000, dvlCallback);  // Subscribe to DVL data

    // Create publishers to send processed data to other ROS topics
    ros::Publisher xpub = n.advertise<std_msgs::Float64>("GZ_X", 1000);        // Publish X position
    ros::Publisher zpub = n.advertise<std_msgs::Float64>("GZ_Z", 1000);        // Publish Z position
    ros::Publisher ypub = n.advertise<std_msgs::Float64>("GZ_Y", 1000);        // Publish Y position
    ros::Publisher dpub = n.advertise<std_msgs::Float64>("GZ_Depth", 1000);    // Publish depth (negative Z)
    ros::Publisher spub = n.advertise<std_msgs::Float64>("GZ_Speed", 1000);    // Publish velocity in X direction
    ros::Publisher ppub = n.advertise<std_msgs::Float64>("GZ_Pitch", 1000);    // Publish pitch angle
    ros::Publisher yapub = n.advertise<std_msgs::Float64>("GZaw", 1000);       // Publish yaw angle (note typo in topic name)
    ros::Publisher hpub = n.advertise<std_msgs::Float64>("GZ_Heading", 1000);  // Publish heading (yaw in degrees)

    // Set the loop rate to 10 Hz (i.e., 10 times per second)
    ros::Rate loop_rate(100);

    // Main loop to process and publish data
    while (ros::ok()) // Continue as long as ROS is running
    {
        // Publish position, velocity, and orientation data
        xpub.publish(msgx);    // Publish X position
        ypub.publish(msgy);    // Publish Y position
        zpub.publish(msgz);    // Publish Z position 
        spub.publish(velx);    // Publish velocity in X direction
        yapub.publish(ya);     // Publish yaw angle
        ppub.publish(p);       // Publish pitch angle
        dpub.publish(msgd);    // Publish depth (negative Z)
        hpub.publish(head);    // Publish heading (yaw in degrees)

        // Log Y position to the console for debugging
        //ROS_INFO("Published to Y: y = %f", msgy.data);

        // Process incoming messages and execute callbacks
        ros::spinOnce();

        // Sleep to maintain the loop rate
        loop_rate.sleep();
    }

    return 0; // Exit the program
}
